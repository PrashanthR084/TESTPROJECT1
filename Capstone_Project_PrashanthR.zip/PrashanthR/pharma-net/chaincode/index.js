'use strict';

const registrationcontract = require('./RegistrationContract.js');
const transferdrugcontract = require('./TransferDrugContract.js');
const viewlifecyclecontract = require('./ViewlifeCycleContract.js');
module.exports.contracts = [RegistrationContract,TransferDrugContract,ViewlifeCycleContract];