docker stop $(docker ps -a -q)
docker rm $(docker ps -a -q)
docker ps -a

docker builder prune --filter type=exec.cachemount
docker rmi $(docker images |grep 'dev-peer')
echo "Completed"
